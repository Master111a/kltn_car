import React from "react";
import PropTypes from "prop-types";
import CardComponent from "../CardComponent/CardComponent";
import carColorConfigs from "../Customizer/CarConfig";
import "./ListCards.css";

const ListCards = ({ selectType }) => {
  if (!carColorConfigs.length || !carColorConfigs[0].colorConfigs) {
    return null;
  }

  return (
    <ul className="cards-list">
      {carColorConfigs[0].colorConfigs.map((item, index) => (
        <li key={index}>
          <div className="list-parts" onClick={() => selectType(index)}>
            <CardComponent
              className="menu-item"
              title={item.title}
              pic={item.image}
            />
          </div>
        </li>
      ))}
    </ul>
  );
};

ListCards.propTypes = {
  selectType: PropTypes.func.isRequired,
};

export default ListCards;
