export const backendDevURL = "https://car-model-threejs.vercel.app";
export const prodbackendDevURL = "https://car-model-threejs.vercel.app";
