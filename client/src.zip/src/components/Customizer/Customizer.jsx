import React, { useCallback } from "react";
import PropTypes from "prop-types";
import "./Customizer.css";
import colorConfig from "./CarConfig";
import gsap from "gsap";
import ListComponent from "../ListCards/ListCards";
import { download, blinkAnimation } from "./customizeUtils";

const Customizer = ({
  modelRef,
  controlsRef,
  rendererRef,
  selectedCarIndex,
  actionRef,
  setColorIndex,
}) => {
  const rotateModel = useCallback(() => {
    gsap.to(modelRef.current.rotation, {
      y: Math.PI * 2,
      duration: 0.8,
      ease: "power1.inOut",
      onComplete: () => {
        controlsRef.current.object.position.set(
          3.2721405209559538,
          1.9869284325362329,
          1.7718614102150416
        );
        actionRef.current.play();
      },
    });
  }, [modelRef, controlsRef, actionRef]);

  const stopModel = useCallback(() => {
    gsap.to(modelRef.current.rotation, {
      y: Math.PI * 2,
      duration: 0.8,
      ease: "power1.inOut",
      onComplete: () => {
        controlsRef.current.object.position.set(
          3.2721405209559538,
          1.9869284325362329,
          1.7718614102150416
        );
        actionRef.current.stop();
      },
    });
  }, [modelRef, controlsRef, actionRef]);

  const onChange = useCallback(
    (index) => {
      setColorIndex(index);
      const position =
        colorConfig[selectedCarIndex].colorConfigs[index].modelPosition;
      gsap.to(controlsRef.current.object.position, {
        ...position,
        duration: 1,
        ease: "power3.inOut",
      });
      colorConfig[selectedCarIndex].colorConfigs[index].types.forEach(
        (type) => {
          blinkAnimation(type, modelRef);
        }
      );
    },
    [modelRef, controlsRef, selectedCarIndex, setColorIndex]
  );

  const selectType = (index) => {
    onChange(index);
  };

  return (
    <div className="color-customizer">
      <div className="color-generator"></div>
      <div className="grid-component">
        <div
          className="list-component"
          style={{ maxHeight: window.innerHeight }}
        >
          <ListComponent
            selectedCarIndex={selectedCarIndex}
            selectType={selectType}
          />
        </div>
        <div className="button-container">
          <CustomButton
            onClick={rotateModel}
            ariaLabel="Surprise me"
            imageSrc="/logo/magic.png"
          />
          <CustomButton
            onClick={() => download(modelRef, rendererRef)}
            ariaLabel="Download Image"
            imageSrc="/logo/download.svg"
          />
          <CustomButton
            onClick={stopModel}
            ariaLabel="Stop me"
            imageSrc="/logo/stop.svg"
            imageStyle={{ color: "grey" }}
          />
        </div>
      </div>
    </div>
  );
};

const CustomButton = ({ onClick, ariaLabel, imageSrc, imageStyle }) => (
  <button
    className="apply-button"
    onClick={onClick}
    aria-label={ariaLabel}
    data-microtip-position="top"
    role="tooltip"
  >
    <img
      className="apply-colors"
      src={imageSrc}
      alt={ariaLabel}
      width={24}
      height={24}
      style={imageStyle}
    />
  </button>
);

CustomButton.propTypes = {
  onClick: PropTypes.func.isRequired,
  ariaLabel: PropTypes.string.isRequired,
  imageSrc: PropTypes.string.isRequired,
  imageStyle: PropTypes.object,
};

Customizer.propTypes = {
  modelRef: PropTypes.object.isRequired,
  controlsRef: PropTypes.object.isRequired,
  rendererRef: PropTypes.object.isRequired,
  selectedCarIndex: PropTypes.number.isRequired,
  actionRef: PropTypes.object.isRequired,
  setColorIndex: PropTypes.func.isRequired,
};

export default Customizer;
