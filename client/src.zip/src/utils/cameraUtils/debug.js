import dat from "lil-gui";

const gui = new dat();

gui.hide();

export default gui;
