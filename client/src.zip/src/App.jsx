import React from "react";
import Playground from "./components/Playground/Playground";
import "./App.css";
// import { Canvas } from "@react-three/fiber";
// import setUpCamera from "./utils/cameraUtils/camera";

const App = () => {
  return (
    <div className="App">
      <Playground />
    </div>
  );
};

export default App;
